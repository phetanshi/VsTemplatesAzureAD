﻿namespace $safeprojectname$.Dtos
{
    public class SampleDTO
    {
    }
}
