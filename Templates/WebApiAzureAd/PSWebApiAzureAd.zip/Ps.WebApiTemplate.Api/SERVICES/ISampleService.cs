﻿namespace $safeprojectname$.Services
{
    public interface ISampleService
    {
        Task Get();
    }
}
