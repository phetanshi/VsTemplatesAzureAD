﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Api.Services
{
    public class SampleServiceTests
    {

    }
}
