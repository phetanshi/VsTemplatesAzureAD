﻿using Microsoft.AspNetCore.Authorization;

namespace $safeprojectname$.Auth
{
    public class AppAuthorizationRequirement : IAuthorizationRequirement
    {
        public AppAuthorizationRequirement()
        {

        }
    }
}
