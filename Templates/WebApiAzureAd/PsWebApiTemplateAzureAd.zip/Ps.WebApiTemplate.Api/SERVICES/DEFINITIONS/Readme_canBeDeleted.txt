﻿1. Every service class in this folder should be inherit from ServiceBase class
2. Every service class should have a dedicated inteface as well